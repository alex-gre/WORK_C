//diceroll.h 
extern int roll_count; 
int roll_n_dice(int dice, int sides);
