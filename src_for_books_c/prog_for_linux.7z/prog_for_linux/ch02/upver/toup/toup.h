void toup (char * str);
