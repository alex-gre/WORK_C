#define STR_SIZE 1024
int readver (char * str);
