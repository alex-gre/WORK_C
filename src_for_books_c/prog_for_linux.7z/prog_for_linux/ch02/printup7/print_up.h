void print_up (const char * str);
