#include <stdio.h>
#include "common.h"

void do_first (void)
{
       printf ("First library\n");
}
