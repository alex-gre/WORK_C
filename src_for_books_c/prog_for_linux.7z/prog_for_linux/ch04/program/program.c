#include "common.h"

int main (void)
{
       do_third ();
       return 0;
}
