#include <stdio.h>
#include "common.h"

void do_second (void)
{
       printf ("Second library\n");
}
