#ifndef COMMON_H
#define COMMON_H

void do_first (void);
void do_second (void);
void do_third (void);

#endif
