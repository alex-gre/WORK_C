#include "common.h"

void do_third (void)
{
       do_first ();
       do_second ();
}
