#ifndef MYENV_H
#define MYENV_H

void mysetenv (const char * name, const char * value);
void myprintenv (const char * name);

#endif
