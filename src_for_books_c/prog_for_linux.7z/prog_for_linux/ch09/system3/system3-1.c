#include <stdlib.h>
#include <stdio.h>

int main (void)
{
	system ("cd abrakadabra");
	fprintf (stderr, "end-of-program\n");
	return 0;
}
