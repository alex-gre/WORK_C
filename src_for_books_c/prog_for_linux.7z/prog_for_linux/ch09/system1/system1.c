#include <stdlib.h>

int main (void)
{
	system ("uname");	
	return 0;
}
