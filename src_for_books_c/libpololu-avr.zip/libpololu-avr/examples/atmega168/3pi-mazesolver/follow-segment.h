void follow_segment();
