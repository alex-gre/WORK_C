/*
 * BlinkLed.c
 *
 * Created: 28.12.2018 11:03:59
 * Author: User
 */

#include <mega16.h>
#include <delay.h>
void main(void)
{
  DDRC = 0b11111111;
while (1)
    {
       PORTC = 0b00000001;
       delay_ms(50);
       PORTC = 0b00000010;
       delay_ms(50);     
       PORTC = 0b00000100;
       delay_ms(50);
       PORTC = 0b00001000;
       delay_ms(50);
    }
}
