#include <avr/io.h> 

int main(void)
{ 
  DDRB = 0xff;
  PORTB = 0xff;
  DDRD |= ~(1<< 4);
  PORTD |= 1<< 4;
  TCCR0 = 0x07;

  while(1)
  {
    if (TCNT0 == 0x14) { PORTB = 0xff; TCNT0 = 0; }
    if (TCNT0 == 0x0A) { PORTB = 0x00; }
  }
}