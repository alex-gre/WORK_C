#define F_CPU 1000000UL

#include <avr/io.h>
#include <avr/iom16.h>
#include <util/delay.h>


int main(void){

  DDRD = 0xFF;

  DDRC = 0x00;

  while(1){
    if(PINC == 0b00000000)  
    PORTD = 0b11111111;
	_delay_ms(200);
	
	PORTD = 0b00000000; 
		_delay_ms(200);
  
  }
   return 0;
}
