**who -- show users currently logged in**

# Learn how to program who command

step0: $ who         # what it is?

step1: $ man who     # Know who uses struct utmp

step2: $ man -k utmp # search utmp manual

step3: $ man utmp    # learn its structure, in see also, find related functions

step4: $ man getutent

step5: Write your own who command!

# Knowing about these before coding.

1. read the data structrue from utmp file
2. display information in a suitable way


