I don't want to write this because you can get whatever you want to know about socket use `man socket`!!!!

Good website of network protocols: http://www.cs.montana.edu/~halla/csci466/

Use Wireshark do some experiments!
