<Understanding Unix/Linux Programming> This book teaches you to learn Unix/Linux C programming by teaching you to write code to implement some Linux commands. Then there are topics such as video games and Socket programming. It is very suitable for people who have a C language basis and Linux basics to get started with Linux C programming. 
The teaching method of this book is also very good: what does it do? -> how does it work? -> let's write our own version!

Enjoy!
