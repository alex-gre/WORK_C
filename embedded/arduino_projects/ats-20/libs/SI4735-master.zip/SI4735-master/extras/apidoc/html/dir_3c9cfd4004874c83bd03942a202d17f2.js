var dir_3c9cfd4004874c83bd03942a202d17f2 =
[
    [ "patch_full.h", "patch__full_8h.html", "patch__full_8h" ],
    [ "patch_init.h", "patch__init_8h.html", "patch__init_8h" ],
    [ "patch_ssb_compressed.h", "patch__ssb__compressed_8h.html", "patch__ssb__compressed_8h" ],
    [ "SI4735.cpp", "_s_i4735_8cpp.html", null ],
    [ "SI4735.h", "_s_i4735_8h.html", "_s_i4735_8h" ]
];