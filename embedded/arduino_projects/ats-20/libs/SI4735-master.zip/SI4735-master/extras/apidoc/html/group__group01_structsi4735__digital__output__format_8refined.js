var group__group01_structsi4735__digital__output__format_8refined =
[
    [ "OSIZE", "group__group01.html#a8e0cf30fb9cddc896d94167934615d42", null ],
    [ "OMONO", "group__group01.html#a61324adf2d131b4df8038991cbca0842", null ],
    [ "OMODE", "group__group01.html#a870fffeed608a381a3abc7e27b22a7ee", null ],
    [ "OFALL", "group__group01.html#abfdc1bd5a8f46739eef7fd4fa44ad600", null ],
    [ "dummy", "group__group01.html#a275876e34cf609db118f3d84b799a790", null ]
];