var group__group01_structsi473x__gpio__ien_8arg =
[
    [ "STCIEN", "group__group01.html#ab09bf67829bc4d5914945a87be624698", null ],
    [ "DUMMY1", "group__group01.html#a3651c40ccc4450f2fc89fa3139dedd5a", null ],
    [ "RSQIEN", "group__group01.html#afa4d97a23dde5b951754d19241a9c117", null ],
    [ "DUMMY2", "group__group01.html#abece94c62273dc7ecfabc565b76dbbe5", null ],
    [ "ERRIEN", "group__group01.html#a459917c791e67eab1cdc18407dc6f507", null ],
    [ "CTSIEN", "group__group01.html#a70cc84d478cf749951dcd0abde88b0ce", null ],
    [ "STCREP", "group__group01.html#a3d9c07e46addffde9770f779a2f71864", null ],
    [ "DUMMY3", "group__group01.html#a613aa5c14b3ccc6304a519292c482ed1", null ],
    [ "RSQREP", "group__group01.html#a7370ae224941074a02e32d4ee6901d56", null ],
    [ "DUMMY4", "group__group01.html#a9182569d693623e6b469099542b303e4", null ]
];