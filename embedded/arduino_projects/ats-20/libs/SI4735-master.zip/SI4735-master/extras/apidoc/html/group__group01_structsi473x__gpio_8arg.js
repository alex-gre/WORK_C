var group__group01_structsi473x__gpio_8arg =
[
    [ "DUMMY1", "group__group01.html#a3651c40ccc4450f2fc89fa3139dedd5a", null ],
    [ "GPO1OEN", "group__group01.html#a9e8c8440a0de220ec3e67ac942bc93ae", null ],
    [ "GPO2OEN", "group__group01.html#a16e39ff0e3715799964f55ae2059869d", null ],
    [ "GPO3OEN", "group__group01.html#a9192331445de77eec6c569dd39215683", null ],
    [ "DUMMY2", "group__group01.html#abece94c62273dc7ecfabc565b76dbbe5", null ]
];