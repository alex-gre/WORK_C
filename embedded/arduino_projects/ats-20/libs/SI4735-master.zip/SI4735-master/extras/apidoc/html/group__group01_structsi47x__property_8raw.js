var group__group01_structsi47x__property_8raw =
[
    [ "byteLow", "group__group01.html#a1f3859652867ab4a967c5caa3e2ab353", null ],
    [ "byteHigh", "group__group01.html#a7b280732d6c370d505d537b0ab9f7e30", null ]
];