var group__group01_structsi4735__digital__output__sample__rate =
[
    [ "DOSR", "group__group01.html#a9988ba829a46409f23d7cb9bb0f156d9", null ]
];