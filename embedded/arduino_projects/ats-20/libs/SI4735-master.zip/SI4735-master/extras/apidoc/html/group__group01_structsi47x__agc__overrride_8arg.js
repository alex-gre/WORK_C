var group__group01_structsi47x__agc__overrride_8arg =
[
    [ "AGCDIS", "group__group01.html#aeaad2cabb6417746b2dd432eda476f55", null ],
    [ "DUMMY", "group__group01.html#abd2103035a8021942390a78a431ba0c4", null ],
    [ "AGCIDX", "group__group01.html#a26bd0af30c189325bd004e10593eb5cd", null ]
];