var group__group01_structsi47x__frontend__agc__control_8field =
[
    [ "ATTN_BACKUP", "group__group01.html#aae22ea8fbb38533f36125b5ccc45338b", null ],
    [ "MIN_GAIN_INDEX", "group__group01.html#aeb3a984f28076574a7347412473f7c13", null ]
];