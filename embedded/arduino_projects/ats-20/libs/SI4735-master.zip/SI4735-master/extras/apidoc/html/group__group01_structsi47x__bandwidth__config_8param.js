var group__group01_structsi47x__bandwidth__config_8param =
[
    [ "AMCHFLT", "group__group01.html#ad992f11e8896f68a81b13fcd6ae2a3b1", null ],
    [ "DUMMY1", "group__group01.html#a3651c40ccc4450f2fc89fa3139dedd5a", null ],
    [ "AMPLFLT", "group__group01.html#ae6741d3dc93d6502bb837ca874ee4f94", null ],
    [ "DUMMY2", "group__group01.html#abece94c62273dc7ecfabc565b76dbbe5", null ]
];