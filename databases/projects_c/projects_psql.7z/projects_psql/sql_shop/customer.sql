create table customer (
    id serial primary key,
    name varchar(255),
    phone varchar(30),
    email varchar(255)
    );