create table product(

   id integer  primary key auto_increment,
   name varchar(255),
   description text,
   price integer
   
   );

