create table customer (
    id integer primary key auto_increment ,
    name varchar(255),
    phone varchar(30),
    email varchar(255)
    );