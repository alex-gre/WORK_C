insert into customer (name,phone,email) values ('name1','+78991111','name1@mail.com');
