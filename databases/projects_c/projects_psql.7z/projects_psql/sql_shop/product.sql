create table product(

   id serial primary key,
   name varchar(255),
   description text,
   price integer
   
   );

