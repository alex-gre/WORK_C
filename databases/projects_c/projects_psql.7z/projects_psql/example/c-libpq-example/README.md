# c-libpq-example

libpq usage example
