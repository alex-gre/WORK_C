/*----------------HTS-Labs----------------*/
/*---------------encrypt headers----------*/

#ifndef unidef__h
#define unidef__h

#ifndef uint8_t
#define uint8_t     unsigned char
#endif

#ifndef uint16_t
#define uint16_t    unsigned short
#endif

#ifndef uint32_t
#define uint32_t    unsigned long
#endif

#ifndef uint64_t
#define uint64_t    unsigned __int64
#endif

#ifndef int8_t
#define int8_t     signed char
#endif

#ifndef int16_t
#define int16_t    signed short
#endif

#ifndef int32_t
#define int32_t    signed long
#endif

#ifndef int64_t
#define int64_t    signed __int64
#endif

#define reorder_bytes(array_of_longs,longs_count,tmp_long,tmp_q)\
    do{\
       for(tmp_q=0;tmp_q < longs_count;tmp_q++){\
       tmp_long=(((uint32_t *)&array_of_longs)[tmp_q]<<16)|\
		(((uint32_t *)&array_of_longs)[tmp_q]>>16);\
	 ((uint32_t *)&array_of_longs)[tmp_q]=((tmp_long & 0xFF0FF00L)>>8)|\
	       ((tmp_long & 0x00FF00FFL)<<8);\
	  }\
    } while(0)
    
#endif



