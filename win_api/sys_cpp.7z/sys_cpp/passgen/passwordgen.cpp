#include <iostream>
#include <string>
#include <random>
#include "cxxopts.hpp"

const char set_lowercase[] = "abcdefghijklmnopqrstuvwxyz";
const char set_uppercase[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const char set_digits[] = "0123456789";
const char set_special[] = "!@#$%^&*_";

class PasswordGenerator {
	std::random_device rd{};
	std::mt19937 rng{ rd() };
public:
	std::string generate(size_t length, bool flag_lowercase, bool flag_uppercase, bool flag_digits, bool flag_special) {
		std::string set_result, password;
        if (!flag_lowercase && !flag_uppercase && !flag_digits && !flag_special)
            return "";
        if (flag_lowercase)
            set_result += set_lowercase;
        if (flag_uppercase)
            set_result += set_uppercase;
        if (flag_digits)
            set_result += set_digits;
        if (flag_special)
            set_result += set_special;
        std::uniform_int_distribution<int> dist(0, set_result.length() - 1);
        for (size_t i = 0; i < length; i++) {
            password += set_result[dist(rng)];
        }
        return password;
	}
};

int main(int argc, char **argv) {
    cxxopts::Options options("passwordgen", "Password Generator v0.0.0.1");
    options.add_options()
        ("l,lowercase", "Include lowercase letters")
        ("u,uppercase", "Include uppercase letters")
        ("d,digits", "Include digits")
        ("s,special", "Include special characters !@#$%^&*_")
        ("n,length", "Password length", cxxopts::value<size_t>()->default_value("8"))
        ("c,count", "How many passwords to generate", cxxopts::value<size_t>()->default_value("1"))
        ("h,help", "Print usage")
        ;

    auto args = options.parse(argc, argv);

    if (args.count("h")) {
        std::cout << options.help() << std::endl;
        exit(0);
    }

    bool f1, f2, f3, f4;
    if (args.count("l") == 0 && args.count("u") == 0
        && args.count("d") == 0 && args.count("s") == 0) {
        f1 = true; f2 = true; f3 = true; f4 = true;
    }
    else {
        f1 = args.count("l");
        f2 = args.count("u");
        f3 = args.count("d");
        f4 = args.count("s");
    }

    PasswordGenerator pg;
    for (size_t i = 0; i < args["c"].as<size_t>(); i++) {
        std::cout << pg.generate(args["n"].as<size_t>(), f1, f2, f3, f4) << std::endl;
    }

    return 0;
}


