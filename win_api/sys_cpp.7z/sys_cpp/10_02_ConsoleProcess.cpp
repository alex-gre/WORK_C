#include <iostream.h>

int main()
{
  cout << "I am created." << endl;
  cout << "Press any key to finish.";
  cin.get();
  
  return 0;
}