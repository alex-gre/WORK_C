//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DlgSample.rc
//
#define IDR_MENU                        101
#define IDD_OPTIONS                     102
#define IDD_TEXT                        104
#define IDC_TEXT                        1001
#define IDC_RED                         1002
#define IDC_GREEN                       1003
#define IDC_BLACK                       1004
#define IDC_APPLY                       1005
#define ID_FILE_EXIT                    40001
#define ID_FILE_OPTIONS                 40002
#define ID_FILE_OPEN                    40003
#define ID_FILE_TEXT                    40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
