#include <windows.h>
#include "resource.h"

extern HINSTANCE hInstance;

LRESULT CALLBACK WindowProc(HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam);
int CALLBACK WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nCmdShow);
