#define IDM_MAINMENU                    1000
#define IDM_ABOUT						1001
#define IDM_EXIT                        1002
#define IDM_RUNTHREADS					1003
#define IDC_STATIC                      -1
