#pragma once

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

typedef LPCTSTR(CALLBACK* RUNTIMEFUNCPTR)(FLOAT fValue);
