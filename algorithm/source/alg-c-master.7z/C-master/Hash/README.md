# Hash algorithms

Overview files **hash.h** and **hash.c**
* sdbm
* djb2
* xor8 (8 bit)
* adler_32 (32 bit)