# Sample solutions for [exercism.io](http://exercism.io/)

This directory contains some sample solutions for **exercism.io**

### Overview 

In this directory you will find (in the right order):
* hello-world
* isogram
* acronym
* word-count
* rna-transcription

