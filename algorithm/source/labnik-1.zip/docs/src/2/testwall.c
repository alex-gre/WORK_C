main(){
 int x;
 int y, z;
 y + 5;
 y = z;
 int *p;
 y = *p;
}