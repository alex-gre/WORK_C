#include <stdlib.h>
int main(int argc, char *argv[]){
	system("ls -la");
	return(0);
}
