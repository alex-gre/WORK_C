#include <stdio.h>
#define MAX_LEN 80
int main(int argc, char *argv[]){
	sytem("myls");
	return(0);
}
