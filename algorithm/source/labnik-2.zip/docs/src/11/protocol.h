struct protocol {
  int time;
  int len;
};

