#include <stdio.h>

int main(int argc, char **argv){
	int i = 247593;
	char str[10];
	sprintf(str, "%d", i);
	printf(str);
	return 0;
}

